(function ($) {
  $(document).ready(function () {
    $('select').material_select();
  });
})(jQuery); // end of jQuery name space